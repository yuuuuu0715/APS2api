#!/bin/bash
set -e
cd "$(dirname "$0")"
chmod +x aps2api new-api start-all.sh 2>/dev/null
bash start-all.sh
